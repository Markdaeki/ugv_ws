#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, MagneticField, JointState
from std_msgs.msg import Float32
from tf2_ros import TransformBroadcaster

from Rosmaster_Lib import Rosmaster


class RosmasterBaseNode(Node):
    @staticmethod
    def euler_to_quaternion(roll: float, pitch: float, yaw: float):
        cr = math.cos(0.5 * roll)
        sr = math.sin(0.5 * roll)
        cp = math.cos(0.5 * pitch)
        sp = math.sin(0.5 * pitch)
        cy = math.cos(0.5 * yaw)
        sy = math.sin(0.5 * yaw)

        qx = sr * cp * cy - cr * sp * sy
        qy = cr * sp * cy + sr * cp * sy
        qz = cr * cp * sy - sr * sp * cy
        qw = cr * cp * cy + sr * sp * sy
        return qx, qy, qz, qw

    def __init__(self):
        super().__init__('rosmaster_base_node')

        # ===== 파라미터 =====
        self.declare_parameter('wheel_radius', 0.097)      # m
        self.declare_parameter('track_width', 0.483)       # m
        self.declare_parameter('ticks_per_rev', 8896.0)
        self.declare_parameter('imu_link', 'imu_link')
        self.declare_parameter('base_frame', 'base_footprint')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('enc_sign', -1.0)
        self.declare_parameter('yaw_scale', 0.765)

        # EKF가 publish_tf: true 라면 여기서는 False 권장 (TF 중복 방지)
        self.declare_parameter('publish_odom_tf', False)

        # ===== 공분산(표준편차, stddev) 파라미터 =====
        # odom pose (엔코더 기반 위치/요)
        self.declare_parameter('odom_pose_x_std', 0.02)     # m
        self.declare_parameter('odom_pose_y_std', 0.02)     # m
        self.declare_parameter('odom_pose_yaw_std', 0.2)    # rad (엔코더 yaw는 덜 신뢰)

        # odom twist (엔코더 기반 속도)
        self.declare_parameter('odom_twist_vx_std', 0.05)   # m/s
        self.declare_parameter('odom_twist_wz_std', 1.0)    # rad/s (엔코더 vyaw는 덜 신뢰)

        # imu gyro z
        self.declare_parameter('imu_gyro_z_std', 0.1)       # rad/s (작을수록 더 신뢰)
        # (orientation은 ekf에서 끌 거라서, 여기서는 큰 의미 없음)
        self.declare_parameter('imu_orientation_yaw_std', 0.3)  # rad (사용 안 하면 큰 값도 무방)

        # ====== set_motor 기반 속도제어 파라미터 ======
        self.declare_parameter('max_vx', 0.61)          # pwm_max일 때 실측 vx
        self.declare_parameter('pwm_max', 90.0)         # 0~90 사용
        self.declare_parameter('pwm_slew_rate', 80.0)   # pwm/sec
        self.declare_parameter('motor_sign_left', 1.0)
        self.declare_parameter('motor_sign_right', 1.0)

        # ----- get params -----
        self.wheel_radius = float(self.get_parameter('wheel_radius').value)
        self.track_width = float(self.get_parameter('track_width').value)
        self.ticks_per_rev = float(self.get_parameter('ticks_per_rev').value)
        self.imu_link = self.get_parameter('imu_link').value
        self.base_frame = self.get_parameter('base_frame').value
        self.odom_frame = self.get_parameter('odom_frame').value
        self.enc_sign = float(self.get_parameter('enc_sign').value)
        self.yaw_scale = float(self.get_parameter('yaw_scale').value)
        self.publish_odom_tf = bool(self.get_parameter('publish_odom_tf').value)

        self.odom_pose_x_std = float(self.get_parameter('odom_pose_x_std').value)
        self.odom_pose_y_std = float(self.get_parameter('odom_pose_y_std').value)
        self.odom_pose_yaw_std = float(self.get_parameter('odom_pose_yaw_std').value)

        self.odom_twist_vx_std = float(self.get_parameter('odom_twist_vx_std').value)
        self.odom_twist_wz_std = float(self.get_parameter('odom_twist_wz_std').value)

        self.imu_gyro_z_std = float(self.get_parameter('imu_gyro_z_std').value)
        self.imu_orientation_yaw_std = float(self.get_parameter('imu_orientation_yaw_std').value)

        self.max_vx = float(self.get_parameter('max_vx').value)
        self.pwm_max = float(self.get_parameter('pwm_max').value)
        self.pwm_slew_rate = float(self.get_parameter('pwm_slew_rate').value)
        self.motor_sign_left = float(self.get_parameter('motor_sign_left').value)
        self.motor_sign_right = float(self.get_parameter('motor_sign_right').value)

        self.get_logger().info(
            f"wheel_radius={self.wheel_radius}, track_width={self.track_width}, ticks_per_rev={self.ticks_per_rev}, "
            f"enc_sign={self.enc_sign}, yaw_scale={self.yaw_scale}, publish_odom_tf={self.publish_odom_tf}\n"
            f"odom_pose_std(x,y,yaw)=({self.odom_pose_x_std},{self.odom_pose_y_std},{self.odom_pose_yaw_std})\n"
            f"odom_twist_std(vx,wz)=({self.odom_twist_vx_std},{self.odom_twist_wz_std}), "
            f"imu_gyro_z_std={self.imu_gyro_z_std}"
        )

        # ===== Rosmaster 보드 초기화 =====
        self.car = Rosmaster()
        self.car.set_car_type(4)  # 4륜 차동

        try:
            self.car.create_receive_threading()
            self.get_logger().info("create_receive_threading() started")
        except Exception as e:
            self.get_logger().error(f"create_receive_threading failed: {e}")

        try:
            self.car.set_auto_report_state(True, False)
        except Exception as e:
            self.get_logger().warn(f"set_auto_report_state failed: {e}")

        # ===== 상태 변수 =====
        self.prev_enc = None
        self.wheel_angles = [0.0, 0.0, 0.0, 0.0]

        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0

        self.imu_yaw = 0.0
        self.last_time = None

        # cmd_vel 목표값 저장
        self.cmd_vx = 0.0
        self.cmd_wz = 0.0
        self.pwmL = 0.0
        self.pwmR = 0.0

        # ===== ROS 통신 =====
        self.cmd_sub = self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_cb, 10)

        self.odom_pub = self.create_publisher(Odometry, 'odom', 50)
        self.joint_pub = self.create_publisher(JointState, 'joint_states', 50)
        self.imu_pub = self.create_publisher(Imu, 'imu/data_raw', 50)
        self.mag_pub = self.create_publisher(MagneticField, 'imu/mag', 50)
        self.vol_pub = self.create_publisher(Float32, 'voltage', 10)

        self.tf_broadcaster = TransformBroadcaster(self)

        self.dt = 0.02
        self.timer = self.create_timer(self.dt, self.update)

    def cmd_vel_cb(self, msg: Twist):
        self.cmd_vx = float(msg.linear.x)
        self.cmd_wz = float(msg.angular.z)

    def update(self):
        now_time = self.get_clock().now()
        now = now_time.to_msg()

        if self.last_time is None:
            dt = self.dt
        else:
            dt = (now_time - self.last_time).nanoseconds * 1.0e-9
            if dt <= 0.0:
                dt = self.dt
        self.last_time = now_time

        # ====== set_motor 기반 차동구동 제어 ======
        def clamp(x, lo, hi):
            return max(lo, min(hi, x))

        def slew(current, target, rate_per_sec, dt_):
            step = rate_per_sec * dt_
            if target > current + step:
                return current + step
            if target < current - step:
                return current - step
            return target

        vx = self.cmd_vx
        wz = self.cmd_wz
        vL = vx - wz * (self.track_width / 2.0)
        vR = vx + wz * (self.track_width / 2.0)

        tgtL = clamp((vL / self.max_vx) * self.pwm_max, -self.pwm_max, self.pwm_max)
        tgtR = clamp((vR / self.max_vx) * self.pwm_max, -self.pwm_max, self.pwm_max)

        self.pwmL = slew(self.pwmL, tgtL, self.pwm_slew_rate, dt)
        self.pwmR = slew(self.pwmR, tgtR, self.pwm_slew_rate, dt)

        pwmL = int(round(self.pwmL * self.motor_sign_left))
        pwmR = int(round(self.pwmR * self.motor_sign_right))

        # (m1,m2)=left, (m3,m4)=right 가정
        self.car.set_motor(pwmL, pwmL, pwmR, pwmR)

        # ---- IMU, MAG, 배터리 ----
        ax, ay, az = self.car.get_accelerometer_data()
        gx, gy, gz = self.car.get_gyroscope_data()
        gz = -gz
        mx, my, mz = self.car.get_magnetometer_data()
        voltage = self.car.get_battery_voltage()

        imu = Imu()
        imu.header.stamp = now
        imu.header.frame_id = self.imu_link

        # gyro Z 적분 (orientation은 ekf에서 끄는 구성이라면 참고값)
        self.imu_yaw += float(gz) * dt
        qx, qy, qz, qw = self.euler_to_quaternion(0.0, 0.0, self.imu_yaw)
        imu.orientation.x = float(qx)
        imu.orientation.y = float(qy)
        imu.orientation.z = float(qz)
        imu.orientation.w = float(qw)

        # orientation covariance (yaw만 의미있게)
        yaw_var = (self.imu_orientation_yaw_std ** 2)
        imu.orientation_covariance = [
            1e-1, 0.0, 0.0,
            0.0, 1e-1, 0.0,
            0.0, 0.0, float(yaw_var),
        ]

        imu.linear_acceleration.x = float(ax)
        imu.linear_acceleration.y = float(ay)
        imu.linear_acceleration.z = float(az)

        imu.angular_velocity.x = float(gx)
        imu.angular_velocity.y = float(gy)
        imu.angular_velocity.z = float(gz)

        # gyro z covariance (여기서 “작을수록 더 신뢰”)
        gz_var = (self.imu_gyro_z_std ** 2)
        imu.angular_velocity_covariance = [
            1e-2, 0.0, 0.0,
            0.0, 1e-2, 0.0,
            0.0, 0.0, float(gz_var),
        ]

        self.imu_pub.publish(imu)

        mag = MagneticField()
        mag.header.stamp = now
        mag.header.frame_id = self.imu_link
        mag.magnetic_field.x = float(mx)
        mag.magnetic_field.y = float(my)
        mag.magnetic_field.z = float(mz)
        self.mag_pub.publish(mag)

        self.vol_pub.publish(Float32(data=float(voltage)))

        # ---- 엔코더 ----
        m1, m2, m3, m4 = self.car.get_motor_encoder()
        m1, m2, m3, m4 = float(m1), float(m2), float(m3), float(m4)

        if self.prev_enc is None:
            self.prev_enc = (m1, m2, m3, m4)
            return

        p1, p2, p3, p4 = self.prev_enc
        d1, d2, d3, d4 = m1 - p1, m2 - p2, m3 - p3, m4 - p4
        self.prev_enc = (m1, m2, m3, m4)

        if self.ticks_per_rev <= 0.0:
            self.get_logger().warn("ticks_per_rev <= 0, skip odom/joints")
            return

        circ = 2.0 * math.pi * self.wheel_radius
        scale = self.enc_sign * (circ / self.ticks_per_rev)

        dist_fl = d1 * scale
        dist_bl = d2 * scale
        dist_fr = d3 * scale
        dist_br = d4 * scale

        dist_left = 0.5 * (dist_fl + dist_bl)
        dist_right = 0.5 * (dist_fr + dist_br)

        ds = 0.5 * (dist_right + dist_left)
        dtheta = 0.0
        if self.track_width != 0.0:
            dtheta = self.yaw_scale * (dist_right - dist_left) / self.track_width

        self.yaw += float(dtheta)
        self.x += float(ds * math.cos(self.yaw))
        self.y += float(ds * math.sin(self.yaw))

        cy = math.cos(self.yaw * 0.5)
        sy = math.sin(self.yaw * 0.5)

        odom = Odometry()
        odom.header.stamp = now
        odom.header.frame_id = self.odom_frame
        odom.child_frame_id = self.base_frame

        odom.pose.pose.position.x = float(self.x)
        odom.pose.pose.position.y = float(self.y)
        odom.pose.pose.position.z = 0.0
        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0
        odom.pose.pose.orientation.z = float(sy)
        odom.pose.pose.orientation.w = float(cy)

        # ===== pose covariance (분산=std^2) =====
        odom.pose.covariance = [0.0] * 36
        odom.pose.covariance[0] = float(self.odom_pose_x_std ** 2)      # x
        odom.pose.covariance[7] = float(self.odom_pose_y_std ** 2)      # y
        odom.pose.covariance[35] = float(self.odom_pose_yaw_std ** 2)   # yaw

        odom.twist.twist.linear.x = float(ds / dt)
        odom.twist.twist.linear.y = 0.0
        odom.twist.twist.angular.z = float(dtheta / dt)

        # ===== twist covariance (EKF에서 vx, vyaw만 쓰므로 거기만 설정) =====
        odom.twist.covariance = [0.0] * 36
        odom.twist.covariance[0] = float(self.odom_twist_vx_std ** 2)     # vx
        odom.twist.covariance[35] = float(self.odom_twist_wz_std ** 2)    # vyaw

        self.odom_pub.publish(odom)

        # ----- TF (odom → base_footprint) -----
        if self.publish_odom_tf:
            t = TransformStamped()
            t.header.stamp = now
            t.header.frame_id = self.odom_frame
            t.child_frame_id = self.base_frame
            t.transform.translation.x = float(self.x)
            t.transform.translation.y = float(self.y)
            t.transform.translation.z = 0.0
            t.transform.rotation.x = 0.0
            t.transform.rotation.y = 0.0
            t.transform.rotation.z = float(sy)
            t.transform.rotation.w = float(cy)
            self.tf_broadcaster.sendTransform(t)

        # ===== JointState =====
        self.wheel_angles[0] += float(dist_fr / self.wheel_radius)  # FR
        self.wheel_angles[1] += float(dist_fl / self.wheel_radius)  # FL
        self.wheel_angles[2] += float(dist_br / self.wheel_radius)  # BR
        self.wheel_angles[3] += float(dist_bl / self.wheel_radius)  # BL

        js = JointState()
        js.header.stamp = now
        js.name = [
            'front_right_joint',
            'front_left_joint',
            'back_right_joint',
            'back_left_joint'
        ]
        js.position = [
            float(self.wheel_angles[0]),
            float(self.wheel_angles[1]),
            float(self.wheel_angles[2]),
            float(self.wheel_angles[3])
        ]
        self.joint_pub.publish(js)


def main(args=None):
    rclpy.init(args=args)
    node = RosmasterBaseNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
